var searchData=
[
  ['_5fmaxc',['_maxC',['../classDarwin.html#a488df498d0b24700075f2326254fec8d',1,'Darwin']]],
  ['_5fmaxr',['_maxR',['../classDarwin.html#ae62a3763723c4c64234d9bfc556df151',1,'Darwin']]]
];
