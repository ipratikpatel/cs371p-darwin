var searchData=
[
  ['name',['name',['../classSpecie.html#aa3874f01ff6f04917cb4c4b6c28a368c',1,'Specie']]],
  ['north',['NORTH',['../Darwin_8h.html#a1711232abf72723b5216c206e6bbb175',1,'Darwin.h']]]
];
