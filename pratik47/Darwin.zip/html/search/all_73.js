var searchData=
[
  ['south',['SOUTH',['../Darwin_8h.html#af3830320fe6287f717dca9669f417950',1,'Darwin.h']]],
  ['specie',['Specie',['../classSpecie.html',1,'Specie'],['../classCreature.html#a042274b096cacbe8d728856d56c00fae',1,'Creature::specie()'],['../classSpecie.html#a5d36c41aa6a23f9606ee84718745fc73',1,'Specie::Specie()'],['../classSpecie.html#a90ea9339b26d9943d594087cff26f1dc',1,'Specie::Specie(const char c)']]]
];
