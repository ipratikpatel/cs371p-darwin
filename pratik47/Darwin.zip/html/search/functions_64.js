var searchData=
[
  ['darwin',['Darwin',['../classDarwin.html#a0bd882cc82538795f11b8ac3a8eb7965',1,'Darwin::Darwin()'],['../classDarwin.html#a281d7a3ef0d1830a0ef3ae2380f715af',1,'Darwin::Darwin(size_t rows, size_t cols)']]],
  ['darwin_5fturn',['darwin_turn',['../classDarwin.html#a6d01e24ba980943621377a4983eaaa01',1,'Darwin']]]
];
