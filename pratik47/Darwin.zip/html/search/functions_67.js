var searchData=
[
  ['get_5fnext_5fcol',['get_next_col',['../Darwin_8c_09_09.html#a0d51742fea009ef2d5a81113187a8acc',1,'Darwin.c++']]],
  ['get_5fnext_5frow',['get_next_row',['../Darwin_8c_09_09.html#a38a9e2ad59a70385ab3fc4efd66ede76',1,'Darwin.c++']]]
];
