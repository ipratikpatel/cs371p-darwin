var searchData=
[
  ['if_5fempty',['if_empty',['../classCreature.html#acac656b6d64bbb43a3c3f922c9a8a33f',1,'Creature']]],
  ['if_5fenemy',['if_enemy',['../classCreature.html#ae0e4de7c2134e3552bd7148a10113c80',1,'Creature']]],
  ['if_5fwall',['if_wall',['../classCreature.html#a62215b1acdd5e0a1942b3ba62c17c62c',1,'Creature']]],
  ['infect',['infect',['../classCreature.html#a691ada80e505d9e47b7e50ee6713f245',1,'Creature']]],
  ['is_5fequal',['is_equal',['../classSpecie.html#af308323644ac6cf8d0146c0756f74df5',1,'Specie']]]
];
