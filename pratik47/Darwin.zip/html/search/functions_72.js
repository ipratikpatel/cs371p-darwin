var searchData=
[
  ['right',['right',['../classCreature.html#a9773790c65f784f774e1967fe5aa2a0e',1,'Creature']]],
  ['run_5fcreature',['run_creature',['../classCreature.html#a80a0eecaa5ded56bc31eca265fa035ac',1,'Creature']]]
];
