var searchData=
[
  ['specie',['Specie',['../classSpecie.html#a5d36c41aa6a23f9606ee84718745fc73',1,'Specie::Specie()'],['../classSpecie.html#a90ea9339b26d9943d594087cff26f1dc',1,'Specie::Specie(const char c)']]]
];
