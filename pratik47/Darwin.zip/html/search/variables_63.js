var searchData=
[
  ['cr_5fcol',['cr_col',['../classCreature.html#ad444a9e365aa86bc576bf23d2586f442',1,'Creature']]],
  ['cr_5fgrid',['cr_grid',['../classCreature.html#ab21b9b3e8eb5a5419d3cda0c126969dd',1,'Creature']]],
  ['cr_5frow',['cr_row',['../classCreature.html#a4774d92b829017effb28eb57a550fec1',1,'Creature']]]
];
