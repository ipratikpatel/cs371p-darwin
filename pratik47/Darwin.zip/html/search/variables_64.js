var searchData=
[
  ['direction',['direction',['../classCreature.html#a6b3f59d2ca15b6781d81c3c141509976',1,'Creature']]]
];
