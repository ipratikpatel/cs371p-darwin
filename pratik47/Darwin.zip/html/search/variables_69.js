var searchData=
[
  ['instructions',['instructions',['../classSpecie.html#aa4d4f1c6056ba35fb7db2b4d1728a66e',1,'Specie']]],
  ['is_5fdone',['is_done',['../classCreature.html#ad866529022148f476cabd0a468f4c0a5',1,'Creature']]]
];
