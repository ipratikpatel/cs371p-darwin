var searchData=
[
  ['name',['name',['../classSpecie.html#aa3874f01ff6f04917cb4c4b6c28a368c',1,'Specie']]]
];
