var searchData=
[
  ['specie',['specie',['../classCreature.html#a042274b096cacbe8d728856d56c00fae',1,'Creature']]]
];
